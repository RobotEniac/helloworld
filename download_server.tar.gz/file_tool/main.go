package main

import (
	"flag"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"net/http/httptrace"
	"net/url"
	"os"
	"path/filepath"
)

func PostPipe(path string, u *url.URL) {
	r, w := io.Pipe()
	m := multipart.NewWriter(w)
	file, err := os.Open(path)
	if err != nil {
		log.Printf("Open file[%s] failed:%s", file, err)
		return
	}
	info, err := file.Stat()
	if err != nil {
		log.Println("file status error:", err)
		return
	}
	totalSize := info.Size()
	ch := make(chan int64)
	go func() {
		var written int64
		for n := range ch{
			written = written + n
			var per float64
			per = float64(written) / float64(totalSize) * 100
			fmt.Printf("\rwritten file[%s]: %d/%d |=====| %%%f",
				path, written, totalSize, per)
		}
		fmt.Println()
	} ()
	go func() {
		defer w.Close()
		defer m.Close()
		defer file.Close()
		defer close(ch)

		part, err := m.CreateFormFile("uploadFile", path)
		if err != nil {
			log.Printf("CreateFormFile failed: %s", err)
			return
		}

		var size int64 = 32 * 1024
		buf := make([]byte, size)
		var written int64
		for {
			nr, er := file.Read(buf)
			if nr > 0 {
				nw, ew := part.Write(buf[0:nr])
				if nw > 0 {
					written += int64(nw)
				}
				if ew != nil {
					err = ew
					log.Println("write network form failed:", err)
					break
				}
				if nr != nw {
					err = io.ErrShortWrite
					log.Println("write size != read size")
					break
				}
			}
			if er != nil {
				if er != io.EOF {
					err = er
				}
				break
			}
			ch <- int64(nr)
		}
	}()
	req, err := http.NewRequest("POST", u.String(), r)
	if err != nil {
		log.Println("Create http request failed:", err)
		os.Exit(1)
	}
	req.Header.Set("Content-Type", m.FormDataContentType())

	trace := &httptrace.ClientTrace{
		GotConn: func(connInfo httptrace.GotConnInfo) {
			log.Printf("Got Conn: %+v\n", connInfo)
		},
		DNSDone: func(dnsInfo httptrace.DNSDoneInfo) {
			log.Printf("Dns info: %+v\n", dnsInfo)
		},
		WroteRequest: func(wroteInfo httptrace.WroteRequestInfo) {
			log.Printf("wrote info: %+v\n", wroteInfo)
		},
	}

	req = req.WithContext(httptrace.WithClientTrace(req.Context(), trace))
	client := &http.Client{}
	response, err := client.Do(req)
	if err != nil {
		log.Println("http response error:", err)
		os.Exit(1)
	}
	defer response.Body.Close()
	body, err := ioutil.ReadAll(response.Body)
	log.Printf("http response:%s\n", string(body))
}

func main() {
	log.SetFlags(log.LstdFlags | log.Lmicroseconds | log.Lshortfile)
	path := flag.String("file", "", "file path of upload file")
	flag.Parse()
	if !flag.Parsed() {
		log.Println("parse flag failed")
		os.Exit(1)
	}
	u, err := url.Parse("http://localhost:9090/upload/" + filepath.Base(*path))
	if err != nil {
		log.Println("parse url failed:", err)
		os.Exit(1)
	}
	q := u.Query()
	if q != nil {
		q.Add("user", "wuhaibo")
		q.Add("cred", "xxx")
		u.RawQuery = q.Encode()
	}
	log.Println("url=", u)
	PostPipe(*path, u)
}
