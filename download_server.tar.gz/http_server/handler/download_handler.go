package handler

import (
	"errors"
	"log"
	"net/http"
	"net/url"
	"strings"
)

type DownloadHandler struct {
	Prefix      string
	BaseDir     string
	fileHandler http.Handler
}

func (h *DownloadHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if h.fileHandler == nil {
		h.fileHandler = http.FileServer(http.Dir(h.BaseDir))
	}
	query := r.URL.Query()
	user := query.Get("user")
	cred := query.Get("cred")
	log.Printf("Incoming donwload request from user[%s], cred[%s]", user, cred)
	if cred != "123" {
		log.Println("download credential is no correct")
		renderError(w, "AUTHENTICATION_FAILED", http.StatusForbidden)
		return
	}
	if h.Prefix == "" {
		h.fileHandler.ServeHTTP(w, r)
	}
	log.Println(r.URL)
	if newUrl, err := removeURLPrefix(r.URL, h.Prefix); err == nil {
		r.URL = newUrl
		log.Println("new url:", r.URL)
		h.fileHandler.ServeHTTP(w, r)
	} else {
		log.Println("file not found", err)
		http.NotFound(w, r)
	}
}

func removeURLPrefix(origin *url.URL, prefix string) (*url.URL, error) {
	pl := strings.Split(strings.Trim(origin.Path, "/"), "/")
	if len(pl) <= 0 || pl[0] != prefix {
		return nil, errors.New("invalid url")
	}
	newUrl := new(url.URL)
	*newUrl = *origin
	path := "/"
	if len(pl) > 1 {
		path = path + strings.Join(pl[1:], "/")
	}
	newUrl.Path = path
	log.Println(newUrl)
	return newUrl, nil
}
