package handler

import (
	"crypto/rand"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

type UploadHandler struct {
	Prefix  string
	BaseDir string
}

const MaxSize = 512 * 1024

func (h *UploadHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	log.Println("Incoming request:", r.URL.Path)
	/*
	if err := r.ParseMultipartForm(MaxSize); err != nil {
		renderError(w, "FILE_TOO_BIG", http.StatusBadRequest)
		return
	}
	*/
	pl := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	log.Printf("len = %d, %v", len(pl), pl)
	if len(pl) <= 1 || pl[0] != h.Prefix {
		log.Println(pl[0])
		log.Println("invalid url:", r.URL.Path, ",", h.Prefix)
		renderError(w, "INVALID_URL", http.StatusBadRequest)
		return
	}
	fileName := pl[1]
	query := r.URL.Query()
	user := query.Get("user")
	cred := query.Get("cred")

	log.Printf("Incoming upload request from user[%s], cred = %s", user, cred)

	file, _, err := r.FormFile("uploadFile")
	if err != nil {
		renderError(w, "INVALID_FILE", http.StatusBadRequest)
		return
	}
	defer file.Close()

	newPath := filepath.Join(h.BaseDir, fileName)
	newFile, err := os.Create(newPath)
	if err != nil {
		renderError(w, "CANT_WRITE_FILE", http.StatusInternalServerError)
		return
	}
	defer newFile.Close()

	var size int64
	if size, err = io.Copy(newFile, file); err != nil || newFile.Close() != nil {
		renderError(w, "CANT_WRITE_FILE", http.StatusInternalServerError)
		return
	}
	log.Printf("write file[%s] size = %d", fileName, size)
	w.Write([]byte("SUCCESS"))
}

func renderError(w http.ResponseWriter, message string, statusCode int) {
	w.WriteHeader(statusCode)
	w.Write([]byte(message))
}

func randToken(len int) string {
	b := make([]byte, len)
	rand.Read(b)
	return fmt.Sprintf("%x", b)
}
