package main

import (
	"http_server/handler"
	"log"
	"net/http"
)

const maxUploadSize = 10 * 1024 * 1024
const uploadPath = "./tmp"

func HttpMain() {
	log.SetFlags(log.Ldate | log.Lmicroseconds | log.Lshortfile)
	http.Handle("/upload/", &handler.UploadHandler{"upload", uploadPath})
	http.Handle("/download/", &handler.DownloadHandler{Prefix: "download", BaseDir:uploadPath})
	log.Println("Server started on localhost:9090, use /upload for uploading and /download/filename for downloading")
	log.Fatal(http.ListenAndServe(":9090", nil))
}

func main() {
	HttpMain()
}
